import React, { useEffect, useMemo, useState } from "react";
import {
  ShieldCheck, Search, MapPin, FileCheck2, ClipboardList, AlertTriangle,
  LayoutDashboard, Menu, X, ExternalLink, Plus, LogIn, LogOut, RefreshCw,
  CheckCircle2, Clock3, Building2, Activity, Info
} from "lucide-react";
import { supabase, supabaseReady } from "./supabase";

const demoRestaurants = [
  { id:"demo-1", name:"Green Leaf Kitchen", city:"Gurugram", area:"Sector 29", address:"Sector 29, Gurugram, Haryana", cuisine:"North Indian", license_number:"DEMO-FSSAI-001", license_status:"demo", verification_status:"sample", latest_inspection:"2026-10-12", hygiene_score:4.5, description:"Demonstration restaurant profile. This is not an actual inspection record." },
  { id:"demo-2", name:"The Daily Bowl", city:"New Delhi", area:"Connaught Place", address:"Connaught Place, New Delhi", cuisine:"Healthy bowls", license_number:"DEMO-FSSAI-002", license_status:"demo", verification_status:"sample", latest_inspection:null, hygiene_score:null, description:"Sample listing; official records have not been connected." },
  { id:"demo-3", name:"Spice Route Cafe", city:"Noida", area:"Sector 18", address:"Sector 18, Noida, Uttar Pradesh", cuisine:"Cafe", license_number:"DEMO-FSSAI-003", license_status:"demo", verification_status:"sample", latest_inspection:"2026-09-20", hygiene_score:3.8, description:"Demonstration data only. Score is illustrative, not an official rating." }
];

function Status({value}) {
  const map = {
    verified:["Officially verified","green"],
    pending:["Pending verification","amber"],
    rejected:["Not verified","red"],
    sample:["Sample data","blue"],
    demo:["Demo only","blue"]
  };
  const [label, tone] = map[value] || ["Not available","muted"];
  return <span className={`pill ${tone}`}><span className="dot"/>{label}</span>;
}

function App() {
  const [restaurants,setRestaurants] = useState(demoRestaurants);
  const [reports,setReports] = useState([]);
  const [query,setQuery] = useState("");
  const [city,setCity] = useState("All locations");
  const [active,setActive] = useState("overview");
  const [selected,setSelected] = useState(null);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState("");
  const [user,setUser] = useState(null);
  const [role,setRole] = useState("public");
  const [authOpen,setAuthOpen] = useState(false);
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [reportForm,setReportForm] = useState({restaurant_id:"",category:"Hygiene concern",details:"",contact_email:""});
  const [restaurantForm,setRestaurantForm] = useState({name:"",city:"",area:"",address:"",cuisine:"",license_number:""});
  const [busy,setBusy] = useState(false);

  async function loadData() {
    if (!supabaseReady) return;
    setLoading(true);
    const [r, p] = await Promise.all([
      supabase.from("restaurants").select("*").order("name"),
      supabase.from("reports").select("id,status,category,created_at,restaurant_id").order("created_at",{ascending:false}).limit(100)
    ]);
    if (!r.error) setRestaurants(r.data || []);
    else setNotice("Database read issue: " + r.error.message);
    if (!p.error) setReports(p.data || []);
    setLoading(false);
  }

  useEffect(() => {
    if (!supabaseReady) return;
    loadData();
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,session) => {
      setUser(session?.user || null);
      if (!session?.user) setRole("public");
      else loadRole(session.user.id);
    });
    return () => subscription.unsubscribe();
  }, []);

  async function loadRole(uid) {
    const {data,error} = await supabase.from("profiles").select("role").eq("id",uid).maybeSingle();
    setRole(!error && data?.role === "admin" ? "admin" : "public");
  }

  const filtered = useMemo(() => restaurants.filter(r => {
    const q = query.toLowerCase();
    const matches = [r.name,r.city,r.area,r.cuisine].filter(Boolean).some(v => v.toLowerCase().includes(q));
    return matches && (city === "All locations" || r.city === city);
  }), [restaurants,query,city]);

  const cities = ["All locations",...new Set(restaurants.map(r=>r.city).filter(Boolean))];
  const verifiedCount = restaurants.filter(r=>r.verification_status==="verified").length;
  const pendingCount = restaurants.filter(r=>r.verification_status==="pending").length;

  async function signIn(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    const {error} = await supabase.auth.signInWithPassword({email,password});
    setBusy(false);
    if (error) setNotice(error.message);
    else { setAuthOpen(false); setPassword(""); setNotice("Signed in."); }
  }
  async function signOut() {
    await supabase.auth.signOut(); setNotice("Signed out.");
  }
  async function submitReport(e) {
    e.preventDefault();
    if (!supabaseReady) { setNotice("Connect Supabase first to submit reports."); return; }
    setBusy(true);
    const {error} = await supabase.from("reports").insert({
      restaurant_id: reportForm.restaurant_id || null,
      category: reportForm.category,
      details: reportForm.details,
      contact_email: reportForm.contact_email || null
    });
    setBusy(false);
    if (error) setNotice("Could not submit: " + error.message);
    else { setNotice("Report submitted. It is awaiting review."); setReportForm({restaurant_id:"",category:"Hygiene concern",details:"",contact_email:""}); setActive("overview"); loadData(); }
  }
  async function addRestaurant(e) {
    e.preventDefault();
    if (!supabaseReady || role!=="admin") return;
    setBusy(true);
    const {error} = await supabase.from("restaurants").insert({...restaurantForm,verification_status:"pending",license_status:"unverified"});
    setBusy(false);
    if (error) setNotice(error.message);
    else { setNotice("Restaurant added with pending verification."); setRestaurantForm({name:"",city:"",area:"",address:"",cuisine:"",license_number:""}); loadData(); }
  }
  async function updateReport(id,status) {
    const {error} = await supabase.from("reports").update({status}).eq("id",id);
    setNotice(error ? error.message : "Report status updated."); loadData();
  }
  async function updateRestaurantStatus(id,status) {
    const {error} = await supabase.from("restaurants").update({verification_status:status}).eq("id",id);
    setNotice(error ? error.message : "Restaurant verification status updated."); loadData();
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ShieldCheck size={23}/></div><div><b>SafeBite</b><small>PUBLIC FOOD SAFETY PORTAL</small></div></div>
      <div className="side-label">PORTAL</div>
      <button className={active==="overview"?"nav active":"nav"} onClick={()=>setActive("overview")}><LayoutDashboard size={18}/> Overview</button>
      <button className={active==="restaurants"?"nav active":"nav"} onClick={()=>setActive("restaurants")}><Building2 size={18}/> Restaurant directory</button>
      <button className={active==="report"?"nav active":"nav"} onClick={()=>setActive("report")}><AlertTriangle size={18}/> Report a concern</button>
      {role==="admin" && <><div className="side-label">ADMINISTRATION</div>
        <button className={active==="admin"?"nav active":"nav"} onClick={()=>setActive("admin")}><ClipboardList size={18}/> Review centre</button>
        <button className={active==="add"?"nav active":"nav"} onClick={()=>setActive("add")}><Plus size={18}/> Add restaurant</button>
      </>}
      <div className="sidebar-bottom">
        <div className="help-card"><Info size={17}/><b>About this portal</b><p>SafeBite helps people find food-safety information. It is not a government agency.</p></div>
        {user ? <button className="nav" onClick={signOut}><LogOut size={18}/> Sign out</button> : <button className="nav" onClick={()=>setAuthOpen(true)}><LogIn size={18}/> Admin sign in</button>}
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div><div className="eyebrow">PUBLIC INFORMATION SERVICE / INDIA</div><h1>{active==="overview"?"Food safety at a glance":active==="restaurants"?"Restaurant directory":active==="report"?"Report a concern":active==="admin"?"Review centre":active==="add"?"Add a restaurant":"Restaurant profile"}</h1></div>
        <div className="top-actions"><span className={`connection ${supabaseReady?"online":"offline"}`}><i/> {supabaseReady?"Database configured":"Demo mode"}</span><button className="icon-button" onClick={loadData} title="Refresh"><RefreshCw size={17}/></button></div>
      </header>

      {notice && <div className="notice"><Info size={16}/>{notice}<button onClick={()=>setNotice("")}><X size={15}/></button></div>}
      {!supabaseReady && <div className="demo-banner"><Info size={18}/><div><b>Preview mode is active.</b> The restaurants shown are fictional sample records. Add your Supabase keys to enable live database features.</div></div>}

      {active==="overview" && <>
        <section className="hero">
          <div><div className="hero-kicker"><ShieldCheck size={15}/> TRANSPARENCY BUILDS TRUST</div><h2>Know more about<br/><em>where your food comes from.</em></h2><p>Explore restaurant information, check the status of available safety records and raise a concern when something doesn't seem right.</p><button className="primary" onClick={()=>setActive("restaurants")}>Explore restaurants <ExternalLink size={16}/></button></div>
          <div className="hero-art"><div className="hero-ring ring1"/><div className="hero-ring ring2"/><div className="hero-shield"><ShieldCheck size={72}/></div><div className="hero-caption">PUBLIC FOOD<br/>SAFETY DIRECTORY</div></div>
        </section>
        <div className="section-heading"><div><div className="eyebrow">PORTAL SNAPSHOT</div><h2>Directory overview</h2></div><span className="muted tiny">Updated when records are refreshed</span></div>
        <section className="stats">
          <div className="stat-card"><div className="stat-icon blue"><Building2/></div><span>Restaurants listed</span><b>{restaurants.length}</b><small>Profiles in directory</small></div>
          <div className="stat-card"><div className="stat-icon green"><ShieldCheck/></div><span>Verified records</span><b>{verifiedCount}</b><small>Officially verified status</small></div>
          <div className="stat-card"><div className="stat-icon amber"><Clock3/></div><span>Awaiting verification</span><b>{pendingCount}</b><small>Review still required</small></div>
          <div className="stat-card"><div className="stat-icon red"><Activity/></div><span>Reports received</span><b>{reports.length}</b><small>Latest 100 records</small></div>
        </section>
        <section className="content-grid">
          <div className="panel"><div className="panel-head"><div><div className="eyebrow">DISCOVER</div><h3>Recently listed restaurants</h3></div><button className="text-button" onClick={()=>setActive("restaurants")}>View directory →</button></div>
            {restaurants.slice(0,4).map(r=><RestaurantRow key={r.id} r={r} onClick={()=>{setSelected(r);setActive("detail")}}/>)}
          </div>
          <div className="panel safety-note"><div className="note-icon"><FileCheck2/></div><h3>Understand the labels</h3><p><b>Verified</b> means an authorised source or administrator has checked the supporting record.</p><p><b>Pending</b> means the record has not completed review.</p><p><b>Sample data</b> is fictional and must never be treated as a real safety assessment.</p><button className="outline" onClick={()=>setActive("restaurants")}>Browse records</button></div>
        </section>
      </>}

      {active==="restaurants" && <section className="panel directory-panel">
        <div className="panel-head"><div><div className="eyebrow">PUBLIC DIRECTORY</div><h2>Find a restaurant</h2><p className="muted">Check the available record and its verification status.</p></div><span className="result-count">{filtered.length} results</span></div>
        <div className="filters"><div className="searchbox"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search restaurant, cuisine or area..."/></div><select value={city} onChange={e=>setCity(e.target.value)}>{cities.map(c=><option key={c}>{c}</option>)}</select></div>
        <div className="restaurant-grid">{filtered.map(r=><RestaurantCard key={r.id} r={r} onClick={()=>{setSelected(r);setActive("detail")}}/>)}</div>
        {filtered.length===0 && <div className="empty">No matching restaurants found.</div>}
      </section>}

      {active==="detail" && selected && <section className="panel detail-panel">
        <button className="text-button" onClick={()=>setActive("restaurants")}>← Back to directory</button>
        <div className="detail-title"><div className="large-building"><Building2 size={30}/></div><div><div className="eyebrow">RESTAURANT RECORD</div><h2>{selected.name}</h2><p className="muted"><MapPin size={14}/> {selected.address || `${selected.area||""} ${selected.city||""}`}</p></div></div>
        <div className="detail-status"><Status value={selected.verification_status}/><span className="muted tiny">Record status</span></div>
        <div className="detail-grid">
          <InfoCell label="Cuisine" value={selected.cuisine||"Not provided"}/><InfoCell label="FSSAI licence number" value={selected.license_number||"Not provided"}/><InfoCell label="Licence status" value={selected.license_status||"Unknown"}/><InfoCell label="Latest inspection date" value={selected.latest_inspection||"No record available"}/>
        </div>
        <div className="record-warning"><AlertTriangle size={19}/><div><b>Check the source before relying on this record.</b><p>{selected.description || "SafeBite displays records and their stated verification status. A missing record does not prove a restaurant is unsafe."}</p></div></div>
        <p className="muted tiny">SafeBite does not conduct inspections or issue FSSAI licences. Official verification requires supporting evidence from an authorised source.</p>
      </section>}

      {active==="report" && <section className="panel form-panel"><div className="eyebrow">PUBLIC FEEDBACK</div><h2>Report a food-safety concern</h2><p className="muted">Share what you observed. Reports are unverified until reviewed. Do not use this form for emergencies.</p>
        <form onSubmit={submitReport} className="form">
          <label>Restaurant (optional)<select value={reportForm.restaurant_id} onChange={e=>setReportForm({...reportForm,restaurant_id:e.target.value})}><option value="">Select a restaurant</option>{restaurants.map(r=><option value={r.id} key={r.id}>{r.name} — {r.city}</option>)}</select></label>
          <label>Concern category<select value={reportForm.category} onChange={e=>setReportForm({...reportForm,category:e.target.value})}>{["Hygiene concern","Food handling","Pest concern","Food quality","Licence information","Other"].map(x=><option key={x}>{x}</option>)}</select></label>
          <label>What did you observe? <textarea required minLength="20" maxLength="2000" value={reportForm.details} onChange={e=>setReportForm({...reportForm,details:e.target.value})} placeholder="Describe the concern factually. Include when you observed it."/></label>
          <label>Email for follow-up (optional)<input type="email" value={reportForm.contact_email} onChange={e=>setReportForm({...reportForm,contact_email:e.target.value})} placeholder="you@example.com"/></label>
          <div className="privacy-note"><Info size={16}/> Please avoid sharing sensitive personal information or unsupported accusations.</div>
          <button className="primary" disabled={busy}>{busy?"Submitting...":"Submit report"} <ExternalLink size={16}/></button>
        </form>
      </section>}

      {active==="admin" && <section className="panel"><div className="panel-head"><div><div className="eyebrow">ADMINISTRATION</div><h2>Report review queue</h2><p className="muted">Review submissions and update their workflow status.</p></div></div>
        {role!=="admin"?<div className="empty">Administrator access is required.</div>:reports.length===0?<div className="empty">No reports have been submitted.</div>:reports.map(p=><div className="review-row" key={p.id}><div><b>{p.category}</b><p className="muted tiny">{new Date(p.created_at).toLocaleString()}</p><Status value={p.status}/></div><select value={p.status} onChange={e=>updateReport(p.id,e.target.value)}><option value="new">New</option><option value="under_review">Under review</option><option value="resolved">Resolved</option><option value="dismissed">Dismissed</option></select></div>)}
        <div className="panel-head subhead"><h3>Restaurant verification queue</h3></div>
        {restaurants.filter(r=>r.verification_status!=="verified").map(r=><div className="review-row" key={r.id}><div><b>{r.name}</b><p className="muted tiny">{r.city} · {r.license_number||"No licence number"}</p><Status value={r.verification_status}/></div><select value={r.verification_status} onChange={e=>updateRestaurantStatus(r.id,e.target.value)}><option value="pending">Pending</option><option value="verified">Verified</option><option value="rejected">Not verified</option></select></div>)}
      </section>}

      {active==="add" && <section className="panel form-panel"><div className="eyebrow">ADMINISTRATION</div><h2>Add restaurant profile</h2><p className="muted">New records start as pending. Verify evidence before changing the status.</p>
        {role!=="admin"?<div className="empty">Administrator access is required.</div>:<form className="form" onSubmit={addRestaurant}>
          {Object.entries({name:"Restaurant name",city:"City",area:"Area / locality",address:"Full address",cuisine:"Cuisine",license_number:"FSSAI licence number"}).map(([key,label])=><label key={key}>{label}<input required={["name","city"].includes(key)} value={restaurantForm[key]} onChange={e=>setRestaurantForm({...restaurantForm,[key]:e.target.value})}/></label>)}
          <button className="primary" disabled={busy}>Save as pending <Plus size={16}/></button>
        </form>}
      </section>}

      <footer><div className="footer-brand"><ShieldCheck size={18}/> SafeBite</div><span>Independent prototype · Not an official government service</span><span>© 2026 SafeBite Project</span></footer>
    </main>

    {authOpen && <div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAuthOpen(false)}><X/></button><div className="brand-mark"><ShieldCheck/></div><h2>Administrator sign in</h2><p className="muted">Use an account created in your Supabase project.</p><form className="form" onSubmit={signIn}><label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="primary" disabled={busy}>Sign in <LogIn size={16}/></button></form></div></div>}
  </div>;
}

function RestaurantRow({r,onClick}) { return <button className="restaurant-row" onClick={onClick}><div className="restaurant-avatar"><Building2/></div><div className="restaurant-row-main"><b>{r.name}</b><span>{r.cuisine||"Cuisine not listed"} · {r.city}</span></div><Status value={r.verification_status}/><ExternalLink size={16} className="row-arrow"/></button>; }
function RestaurantCard({r,onClick}) { return <button className="restaurant-card" onClick={onClick}><div className="card-top"><div className="restaurant-avatar"><Building2/></div><Status value={r.verification_status}/></div><h3>{r.name}</h3><p><MapPin size={14}/> {r.area||r.city}, {r.city}</p><div className="card-meta"><span>{r.cuisine||"Cuisine not listed"}</span><span>{r.latest_inspection?`Inspection: ${r.latest_inspection}`:"No inspection record"}</span></div><div className="card-link">View safety record <ExternalLink size={14}/></div></button>; }
function InfoCell({label,value}) { return <div className="info-cell"><span>{label}</span><b>{value}</b></div>; }

export default App;