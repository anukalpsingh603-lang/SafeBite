-- SafeBite database schema for Supabase.
-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'public' check (role in ('public','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null,
  area text,
  address text,
  cuisine text,
  license_number text,
  license_status text not null default 'unverified'
    check (license_status in ('unverified','verified','expired','demo')),
  verification_status text not null default 'pending'
    check (verification_status in ('pending','verified','rejected','sample')),
  latest_inspection date,
  hygiene_score numeric(2,1) check (hygiene_score between 1 and 5),
  description text,
  evidence_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  category text not null,
  details text not null check (char_length(details) between 20 and 2000),
  contact_email text,
  status text not null default 'new'
    check (status in ('new','under_review','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create index if not exists restaurants_city_idx on public.restaurants(city);
create index if not exists restaurants_name_idx on public.restaurants(name);
create index if not exists reports_created_idx on public.reports(created_at desc);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.restaurants enable row level security;
alter table public.reports enable row level security;

drop policy if exists "Profiles readable by own user" on public.profiles;
create policy "Profiles readable by own user" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists "Admins manage profiles" on public.profiles;
create policy "Admins manage profiles" on public.profiles
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Public can read restaurant directory" on public.restaurants;
create policy "Public can read restaurant directory" on public.restaurants
for select to anon, authenticated using (true);

drop policy if exists "Admins insert restaurants" on public.restaurants;
create policy "Admins insert restaurants" on public.restaurants
for insert to authenticated with check (public.is_admin());

drop policy if exists "Admins update restaurants" on public.restaurants;
create policy "Admins update restaurants" on public.restaurants
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admins delete restaurants" on public.restaurants;
create policy "Admins delete restaurants" on public.restaurants
for delete to authenticated using (public.is_admin());

drop policy if exists "Anyone can submit a report" on public.reports;
create policy "Anyone can submit a report" on public.reports
for insert to anon, authenticated with check (
  char_length(details) between 20 and 2000
  and status = 'new'
);

drop policy if exists "Admins read reports" on public.reports;
create policy "Admins read reports" on public.reports
for select to authenticated using (public.is_admin());

drop policy if exists "Admins update reports" on public.reports;
create policy "Admins update reports" on public.reports
for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Create an account in Supabase Authentication first, then replace the email below
-- with that exact account email and run this statement to grant administrator access.
-- Never expose an admin password or service-role key in frontend code.
-- insert into public.profiles (id, role)
-- select id, 'admin' from auth.users where email = 'YOUR_ADMIN_EMAIL'
-- on conflict (id) do update set role = 'admin';

-- Optional sample data. These are fictional examples, not real restaurants or ratings.
insert into public.restaurants
(name,city,area,address,cuisine,license_number,license_status,verification_status,latest_inspection,hygiene_score,description)
values
('Green Leaf Kitchen','Gurugram','Sector 29','Sector 29, Gurugram, Haryana','North Indian','DEMO-FSSAI-001','demo','sample','2026-10-12',4.5,'Fictional sample record. Not an actual inspection or official rating.'),
('The Daily Bowl','New Delhi','Connaught Place','Connaught Place, New Delhi','Healthy bowls','DEMO-FSSAI-002','demo','sample',null,null,'Fictional sample listing. Official records have not been connected.')
on conflict do nothing;